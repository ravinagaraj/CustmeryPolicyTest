var expiryDateVal = context.getVariable("response.header.Expires");
if(expiryDateVal != null){
	var expiryDate = new Date(expiryDateVal);
	var currentdate = new Date();
	var dif = expiryDate - currentdate;
	
	if(dif > 1) {
		var SecondsDifference = dif / 1000;
		var SecondsBetweenDates = Math.abs(SecondsDifference);
		var differenceVal = Math.floor(SecondsBetweenDates);
		context.setVariable("expiryValueInSec",differenceVal+'');
	}
}