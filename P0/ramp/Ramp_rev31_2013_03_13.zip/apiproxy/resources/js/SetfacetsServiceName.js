flow.setVariable("servicenameValue","facets");
flow.setVariable("operationNameValue","facets");

