flow.setVariable("servicenameValue","sources");
flow.setVariable("operationNameValue","sources");

