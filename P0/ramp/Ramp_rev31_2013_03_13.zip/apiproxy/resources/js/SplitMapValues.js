var responseVal = flow.getVariable("responseVal");
var splitVal = responseVal.split("::");
flow.setVariable("siteName",splitVal[0]);
flow.setVariable("authHeader",splitVal[1]);