flow.setVariable("servicenameValue","user");
flow.setVariable("operationNameValue","user");

