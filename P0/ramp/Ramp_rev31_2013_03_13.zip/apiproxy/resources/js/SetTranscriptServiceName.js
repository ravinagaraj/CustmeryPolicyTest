flow.setVariable("servicenameValue","transcript");
flow.setVariable("operationNameValue","transcript");

