var envName = flow.getVariable("environment.name");

	var rampBackendURL = "https://cdnapi.ramp.com";
	var rampMetaQURL = "https://metaqw.api.ramp.com";
	var rampMetaQURLRead = "https://metaqapiv2.ramp.com";

	
flow.setVariable("flow.resource.name",flow.getVariable("request.uri"));
flow.setVariable("targetURLKey",flow.getVariable("proxy.pathsuffix"));

var requestPath = flow.getVariable("proxy.pathsuffix");
var updatedRequestPath = requestPath.replace("/content","");
var urlSplitArray = updatedRequestPath.split("/");
var siteName = urlSplitArray[1];

if(flow.getVariable("client.ssl.enabled") && siteName != null && siteName != "v1"){
	flow.setVariable("siteName",siteName);
	flow.setVariable("siteNameUrl","/"+siteName);
	updatedRequestPath = updatedRequestPath.replace("/"+siteName,"");
}
flow.setVariable("authHeader",flow.getVariable("request.header.Authorization"));

flow.setVariable("updatedRequestPath",updatedRequestPath);
var apiKeyVal = flow.getVariable("apikey");
if(flow.getVariable("client.ssl.enabled") == true && apiKeyVal == null){
	flow.setVariable("secureFlow",true);	
}
flow.setVariable("rampBackendURL",rampBackendURL);
flow.setVariable("rampRestreadapiURL",rampBackendURL+"/restreadapi");
flow.setVariable("rampMediacloudapiURL",rampBackendURL+"/mediacloudapi");
flow.setVariable("rampMetaQURL",rampMetaQURL);
flow.setVariable("rampMetaQURLRead",rampMetaQURLRead);
flow.setVariable("originFromRequest",flow.getVariable("request.header.Origin"));