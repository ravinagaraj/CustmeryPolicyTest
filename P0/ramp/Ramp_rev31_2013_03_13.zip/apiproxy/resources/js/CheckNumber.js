if(isNaN(parseInt(flow.getVariable("developer.app.name"))))
	flow.setVariable("CheckNum","1");
else
	flow.setVariable("CheckNum","0");
