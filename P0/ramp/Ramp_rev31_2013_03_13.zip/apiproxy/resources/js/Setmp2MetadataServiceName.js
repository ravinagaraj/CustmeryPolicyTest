flow.setVariable("servicenameValue","mp2");
flow.setVariable("operationNameValue","metadata");