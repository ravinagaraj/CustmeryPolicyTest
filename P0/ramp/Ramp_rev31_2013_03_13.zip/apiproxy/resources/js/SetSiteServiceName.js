flow.setVariable("servicenameValue","site");
flow.setVariable("operationNameValue","site");