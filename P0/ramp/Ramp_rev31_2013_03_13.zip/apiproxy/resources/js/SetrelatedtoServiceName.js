flow.setVariable("servicenameValue","relatedto");
flow.setVariable("operationNameValue","relatedto");

