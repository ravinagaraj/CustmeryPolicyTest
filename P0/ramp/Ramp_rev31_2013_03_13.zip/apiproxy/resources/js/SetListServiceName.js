flow.setVariable("servicenameValue","list");
flow.setVariable("operationNameValue","list");

