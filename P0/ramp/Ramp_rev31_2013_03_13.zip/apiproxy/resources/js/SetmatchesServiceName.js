flow.setVariable("servicenameValue","matches");
flow.setVariable("operationNameValue","matches");

