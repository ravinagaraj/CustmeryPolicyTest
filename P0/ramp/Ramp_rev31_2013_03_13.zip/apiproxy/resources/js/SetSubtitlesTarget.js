var formatVal = flow.getVariable("request.queryparam.format");
if(formatVal == null){
	formatVal = "";
}
var syndicationVal = flow.getVariable("request.queryparam.syndication");
if(syndicationVal == null || syndicationVal == ""){
	flow.setVariable("targeturlVal",flow.getVariable("rampMediacloudapiURL")+"/"+flow.getVariable("siteName")+"?syndication=dataservices&xsl="+formatVal+".xsl&"+flow.getVariable("request.querystring"));
}else {
	flow.setVariable("targeturlVal",flow.getVariable("rampMediacloudapiURL")+"/"+flow.getVariable("siteName")+"?xsl="+formatVal+".xsl&"+flow.getVariable("request.querystring"));
}