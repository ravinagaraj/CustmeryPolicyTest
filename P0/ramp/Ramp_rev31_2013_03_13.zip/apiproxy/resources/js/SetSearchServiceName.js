flow.setVariable("servicenameValue","search");
flow.setVariable("operationNameValue","search");

