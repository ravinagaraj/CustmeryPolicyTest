flow.setVariable("servicenameValue","collections");
flow.setVariable("operationNameValue","collections");

