flow.setVariable("servicenameValue","item");
flow.setVariable("operationNameValue","items");

