var rateLimitUsedCount = flow.getVariable("ratelimit.RampQuotaPolicy.used.count");
var rateLimitAllowedCount = flow.getVariable("ratelimit.RampQuotaPolicy.allowed.count");
var rateLimitUsedPercentage = Math.round(rateLimitUsedCount/rateLimitAllowedCount*100);
flow.setVariable("rateLimitUsedPercentage",rateLimitUsedPercentage);