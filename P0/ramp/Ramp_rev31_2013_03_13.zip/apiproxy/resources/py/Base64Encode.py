import base64
userName = flow.getVariable("userName");
passWord = flow.getVariable("passWord");
encoded = base64.encodestring(userName+":"+passWord)
flow.setVariable("kmsAuthHeader", encoded);