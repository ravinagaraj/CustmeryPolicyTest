flow.setVariable("servicenameValue","rules");
flow.setVariable("operationNameValue","rules");