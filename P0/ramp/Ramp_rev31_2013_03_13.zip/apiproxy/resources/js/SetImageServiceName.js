flow.setVariable("servicenameValue","image");
flow.setVariable("operationNameValue","image");

