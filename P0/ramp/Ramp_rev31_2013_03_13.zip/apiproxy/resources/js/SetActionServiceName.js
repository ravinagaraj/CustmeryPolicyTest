flow.setVariable("servicenameValue","actions");
flow.setVariable("operationNameValue","actions");

