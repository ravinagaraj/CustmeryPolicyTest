var cachekey = flow.getVariable("request.path")+ '?'+ request.getVariable("querystring") +'&site='+flow.getVariable("siteName");
flow.setVariable("ramp.cachekey.generic",cachekey);