flow.setVariable("servicenameValue","topics");
flow.setVariable("operationNameValue","topics");