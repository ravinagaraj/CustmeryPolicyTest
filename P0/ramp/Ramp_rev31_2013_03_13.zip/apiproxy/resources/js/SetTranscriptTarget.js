flow.setVariable("targeturlVal",flow.getVariable("rampRestreadapiURL")+"/" + flow.getVariable("siteName") +flow.getVariable("updatedRequestPath")+"?"+flow.getVariable("request.querystring"));

