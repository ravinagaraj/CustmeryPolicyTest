flow.setVariable("servicenameValue","tags");
flow.setVariable("operationNameValue","tags");

