var requestPath = flow.getVariable("updatedRequestPath");
flow.setVariable("myVar",requestPath);
var splitedPath = requestPath.split("/");
var updatedRequestPath = requestPath.replace(splitedPath[1],"").replace(splitedPath[2],"").replace("//","");
flow.setVariable("myVarafterUpdate",updatedRequestPath);
flow.setVariable("updatedRequestPath",updatedRequestPath);