flow.setVariable("servicenameValue","terms");
flow.setVariable("operationNameValue","terms");

